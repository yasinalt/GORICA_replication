bootSZ <- function(mydata,B) {
  
  mydata<-t(mydata)
  
  if (length(mydata[mydata==0])==0) { print("There is no sampling zeros in the contingency table.")}
  
  PS<-which(mydata==0)
  
  
  D<-length(mydata)
  
  ObsF=rep(1:D,mydata)
  
  obstotal=length(ObsF)
  
  bootstrap=matrix(c(NA),nrow=B,ncol=D,byrow=TRUE)
  
  conttab=matrix(c(NA),nrow=1,ncol=D,byrow=TRUE)
  
  
  for (b in 1:B) {
    
    index=c(1:obstotal)
    indexx=sample(1:obstotal,replace=TRUE)
    
    
    A=ObsF[indexx]
    
    
    for (i in 1:D) {
      conttab[,i]=length(A[A==i])
    }
    
    if (length(PS) > 0) {conttab[PS]<-1/D}
    
    
    conttab=conttab/(sum(conttab))
    bootstrap[b,]=conttab 
    
    
    }
  
  if (sum(is.na(bootstrap))>0) {print("The positions of sampling zeros are not correct.") }
  
  
  if (sum(is.na(bootstrap))==0 ) {return(list(bootstrap)) }
  
   }




