library(gorica)

set.seed(111)

mydata1 <- as.table(matrix(c(0, 5, 6, 3), nrow = 2, ncol = 2, byrow = TRUE))
mydata1


x<-bootSZ(mydata1,B=1000)[[1]]


eta<-(x[,1]*x[,4])-(x[,2]*x[,3])

est1<-mean(eta)

var1<-as.matrix(var(eta))

names(est1)<-"a"

res1 <- gorica(est1, Sigma = var1, hypothesis = "a < 0;
a = 0;
a > 0",comparison="none")

res1


###########################################################################

set.seed(111)

#Displaying the data on R console
mydata2 <-as.table(matrix(c(1,10,21,11),nrow=2, ncol=2, byrow = TRUE))
mydata2

x<-bootSZ(mydata2,B=1000)[[1]]

eta<-(x[,1]*x[,4])-(x[,2]*x[,3])

est2<-mean(eta)

var2<-as.matrix(var(eta))

names(est2)<-"a"

res2 <- gorica(est2, Sigma = var2, hypothesis = "a < 0;
a = 0;
a > 0",comparison="none")

res2

################################################################


set.seed(111)

#Displaying the data on R console
mydata3 <-as.table(matrix(c(0,1,5,5),nrow=2, ncol=2, byrow = TRUE))
mydata3

x<-bootSZ(mydata3,B=1000)[[1]]

eta<-(x[,1]*x[,4])-(x[,2]*x[,3])

est3<-mean(eta)

var3<-as.matrix(var(eta))

names(est3)<-"a"

res3 <- gorica(est3, Sigma = var3, hypothesis = "a < 0;
a = 0;
a > 0",comparison="none")

res3

