library(gorica)

set.seed(111)

mydata1 <- as.table(matrix(c(1,10,21,11,11,7,18,21),nrow=4, ncol=2,  byrow = TRUE))
mydata1


x<-bootSZ(mydata1,B=1000)[[1]]


eta1<-(x[,1]*x[,4])-(x[,2]*x[,3])
eta2<-(x[,5]*x[,8])-(x[,6]*x[,7])


eta<-cbind(eta1,eta2)

est1<-apply(eta,2,mean)
covmtrx1<-as.matrix(cov(eta))

names(est1)<-c("a","b")

res1 <- gorica(est1, Sigma = covmtrx1, hypothesis = "a < 0 & b < 0;
a < 0 & b = 0;
a > 0 & b > 0")

res1



#############################################################################


library(gorica)

set.seed(111)

mydata2 <- as.table(matrix(c(0,1,5,5,1,1,6,7),nrow=4, ncol=2,  byrow = TRUE))
mydata2


x<-bootSZ(mydata2,B=1000)[[1]]


eta1<-(x[,1]*x[,4])-(x[,2]*x[,3])
eta2<-(x[,5]*x[,8])-(x[,6]*x[,7])


eta<-cbind(eta1,eta2)

est2<-apply(eta,2,mean)
covmtrx2<-as.matrix(var(eta))

names(est2)<-c("a","b")

res2 <- gorica(est2, Sigma = covmtrx2, hypothesis = "a < 0 & b < 0;
a < 0 & b = 0;
a > 0 & b > 0")

res2













#Displaying the data on R console
mydata2 <-as.table(matrix(c(0,1,5,5,1,1,6,7),nrow=4, ncol=2, byrow = TRUE))
mydata2


est2<-c(-0.004919749,  0.001763314)
covmtrx2<-matrix(c(5.892241e-05, 4.586433e-06, 4.586433e-06, 2.164491e-04),nrow=2,ncol=2,byrow=TRUE)

names(est2)<-c("a","b")

res2 <- gorica(est2, Sigma = covmtrx2, hypothesis = "a < 0 & b < 0;
a < 0 & b = 0;
a > 0 & b > 0")

res2

